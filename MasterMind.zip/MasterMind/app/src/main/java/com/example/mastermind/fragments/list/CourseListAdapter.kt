package com.example.roomapp.fragments.list

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.mastermind.R
import com.example.mastermind.data.Course

class CourseListAdapter : RecyclerView.Adapter<CourseListAdapter.MyViewHolder>(){

    private var courseList = emptyList<Course>()

    class MyViewHolder(val itemView : View) : RecyclerView.ViewHolder(itemView){}

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {

        return MyViewHolder(LayoutInflater.from(parent.context).inflate(R.layout.course_row, parent, false))

    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {

        val currentItem = courseList[position]
        holder.itemView.tvCourseCode.text = currentItem.code.toString()

    }

    override fun getItemCount() = courseList.size

    fun setData(courses : List<Course>){
        this.courseList = courses
        notifyDataSetChanged()
    }

}
