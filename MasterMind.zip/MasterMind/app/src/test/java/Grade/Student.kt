package com.example.mastermind.ui.Grade

data class Student(var id: Int = 0,
                   var fullName: String,
                   var course: String,
                   var quizScore: Double,
                   var midScore: Double,
                   var assignmentScore: Double,
                   var finalScore: Double
                   )
